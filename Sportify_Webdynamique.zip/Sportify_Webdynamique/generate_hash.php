<?php
echo password_hash('admin222', PASSWORD_DEFAULT);
